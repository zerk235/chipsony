// Модуль личного профиля пользователя.
//
// Аутентификации в Supabase нет: пользователь опознаётся по параметрам запуска
// VK (подпись sign), их проверяет Edge Function supabase/functions/me.
// Поэтому здесь нет ни supabase.auth, ни anon-ключа — только HTTP-запросы
// к функции с сырыми параметрами запуска внутри.
import { getLaunchQuery, getVkUserInfo, launchDiagnostics } from './lib/vkUser';

const BASE = (import.meta.env.VITE_PROFILE_ENDPOINT || '').trim()
  || (import.meta.env.VITE_SUPABASE_URL
    ? `${String(import.meta.env.VITE_SUPABASE_URL).replace(/\/+$/, '')}/functions/v1/me`
    : '');

export function isProfileConfigured() {
  return Boolean(BASE);
}

/** Понимает на сетевом уровне: интернет в порядке, а supabase.co — нет. */
async function probeReachability() {
  const parts = [];
  const probe = async (url, label) => {
    try {
      // Тот же «простой» POST, что и в call() — точная симуляция пути к серверу.
      await fetch(url, { method: 'POST', mode: 'no-cors', body: '{}', cache: 'no-store' });
      parts.push(`${label}:доступен`);
    } catch {
      parts.push(`${label}:недоступен`);
    }
  };
  await Promise.all([probe(BASE, 'supabase.co'), probe('https://vk.com/', 'vk')]);
  const internet = parts.find((p) => p.startsWith('vk:'))?.includes('доступен');
  return `Проверка сети: ${parts.join(', ')}${internet ? '' : ' (похоже, нет сети вообще)'}.`;
}

/** «Отпечаток» запроса из браузера: какими способами до сервера дотягивается. */
async function fetchFingerprint() {
  const out = [];
  const probe = async (label, opts) => {
    try {
      await fetch(BASE, { ...opts, cache: 'no-store' });
      out.push(`${label}:ok`);
    } catch (e) {
      out.push(`${label}:fail`);
    }
  };
  await Promise.all([
    probe('cors', { method: 'POST', body: '{}' }),
    probe('noCors', { method: 'POST', mode: 'no-cors', body: '{}' }),
    new Promise((resolve) => {
      try {
        const xhr = new XMLHttpRequest();
        xhr.open('POST', BASE, true);
        xhr.onload = () => {
          out.push(`xhr:ok(${xhr.status})`);
          resolve();
        };
        xhr.onerror = () => {
          out.push('xhr:fail');
          resolve();
        };
        xhr.send('{}');
      } catch (e) {
        out.push('xhr:fail');
        resolve();
      }
    }),
  ]);
  out.push(`secure:${window.isSecureContext}`);
  out.push(`origin:${window.location.origin}`);
  return out.join(',');
}

async function call(body) {
  if (!BASE) {
    throw new Error('Профиль пока не подключён: не задан VITE_SUPABASE_URL');
  }

  const launchQuery = getLaunchQuery();
  if (!launchQuery) {
    const diag = await launchDiagnostics();
    console.error('[chipsony] параметры запуска не найдены:', diag);
    throw new Error(`Не удалось получить данные запуска от VK (${diag})`);
  }

  const userInfo = await getVkUserInfo();

  let response;
  try {
    // Без заголовка content-type запрос становится «простым» и не требует
    // preflight OPTIONS, который в iframe VK нестабилен. Edge Function парсит
    // JSON из тела не глядя на заголовок.
    response = await fetch(BASE, {
      method: 'POST',
      body: JSON.stringify({ launchQuery, userInfo, ...body }),
    });
  } catch (err) {
    console.error('[chipsony] fetch не смог достучаться до функции:', err);
    const probe = await probeReachability();
    const fp = await fetchFingerprint();
    throw new Error(`Сервер профиля недоступен (${new URL(BASE).host}). ${probe} Fingerprint: ${fp}`);
  }

  let payload = null;
  try {
    payload = await response.json();
  } catch {}

  if (!response.ok) {
    throw new Error(payload?.error || `Сервер профиля ответил ${response.status}`);
  }

  return payload?.profile ?? null;
}

/** Загружает профиль, при первом обращении создаёт его на сервере. */
export function loadProfile() {
  return call({});
}

/** Сохраняет поля профиля: display_name, phone, city. */
export function updateProfile(patch) {
  return call({ patch });
}

const MAX_AVATAR_BYTES = 2 * 1024 * 1024;
const EXT_BY_TYPE = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
};

function readAsBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Не удалось прочитать файл'));
    reader.onload = () => {
      const result = String(reader.result || '');
      const comma = result.indexOf(',');
      resolve(comma === -1 ? result : result.slice(comma + 1));
    };
    reader.readAsDataURL(file);
  });
}

/** Загружает аватар и прикрепляет ссылку к профилю. */
export async function uploadAvatar(file) {
  if (!file) throw new Error('Файл не выбран');
  if (file.size > MAX_AVATAR_BYTES) throw new Error('Аватар не больше 2 МБ');

  const ext = EXT_BY_TYPE[file.type];
  if (!ext) throw new Error('Подойдёт только JPG, PNG или WEBP');

  const avatarBase64 = await readAsBase64(file);
  return call({ avatarBase64, avatarExt: ext });
}
