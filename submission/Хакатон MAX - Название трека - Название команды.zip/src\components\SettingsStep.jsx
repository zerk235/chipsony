import { Button, Caption, Div, Group, Header, Radio, RadioGroup, Spacing } from '@vkontakte/vkui';
import { Icon28QrCodeOutline, Icon28TicketOutline, Icon28UserOutline } from '@vkontakte/icons';
import { plural } from '../lib/format';

const THEME_OPTIONS = [
  { value: 'auto', label: 'Как в ВК / системе' },
  { value: 'light', label: 'Светлая тема' },
  { value: 'dark', label: 'Тёмная тема' },
];

export function SettingsStep({ themePref, onTheme, cartCount, onOpenProfile, onOpenTickets, onOpenScan, onExit, onResetCart }) {
  return (
    <>
      <Div>
        <Button size="l" mode="secondary" stretched onClick={onExit}>
          ← Вернуться в афишу
        </Button>
      </Div>

      <Group header={<Header mode="secondary">Оформление</Header>}>
        <RadioGroup>
          {THEME_OPTIONS.map((opt) => (
            <Div key={opt.value}>
              <Radio value={opt.value} checked={themePref === opt.value} onChange={() => onTheme(opt.value)}>
                {opt.label}
              </Radio>
            </Div>
          ))}
        </RadioGroup>
      </Group>

      <Group header={<Header mode="secondary">Корзина</Header>}>
        <Div>
          <Caption className="vkui--ToneNeutral" style={{ display: 'block' }}>
            Сейчас в корзине: {cartCount} {plural(cartCount, 'билет', 'билета', 'билетов')}
          </Caption>
          <Spacing size={12} />
          <Button size="l" mode="secondary" stretched disabled={cartCount === 0} onClick={onResetCart}>
            Очистить корзину
          </Button>
        </Div>
      </Group>

      <Group header={<Header mode="secondary">Аккаунт</Header>}>
        <Div>
          <Button size="l" mode="secondary" stretched before={<Icon28UserOutline />} onClick={onOpenProfile}>
            Мой профиль
          </Button>
          <Spacing size={8} />
          <Button size="l" mode="secondary" stretched before={<Icon28TicketOutline />} onClick={onOpenTickets}>
            Мои билеты
          </Button>
        </Div>
      </Group>

      <Group header={<Header mode="secondary">Для организатора</Header>}>
        <Div>
          <Button size="l" mode="secondary" stretched before={<Icon28QrCodeOutline />} onClick={onOpenScan}>
            Сканер QR-билетов
          </Button>
        </Div>
      </Group>

      <Group header={<Header mode="secondary">О приложении</Header>}>
        <Div>
          <Caption className="vkui--ToneNeutral" style={{ display: 'block' }}>
            Чипсоны — афиша событий. Регистрация бесплатная: билет с QR-кодом приходит сразу.
          </Caption>
        </Div>
      </Group>
    </>
  );
}
